/**
 * Name: Andrew Fu
 * Period: 5
 * Date: March 25th
 * Time: 0:56:48
 * 
 * I found the end result of the life GUI lab to be satisfying, and I enjoyed doing the lab. However, 
 * it bothered me that I am not able to clean up my code due to time constraints, so some of the 
 * code seems unconventional. Initially, I was confused about the necessity of the generation 
 * listener array list, and only after having read the slides thoroughly, I recognized its 
 * application. While working on generation listeners, I was puzzled by the program crashing, and 
 * only when I had read the error message, I understood that I needed to initialize the array list.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class P5_Fu_Andrew_LifeGUI2 extends Application implements GenerationListener {

	P5_Fu_Andrew_LifeModel model;
	BooleanGridPane view;
	BorderPane borderPane;
	Scene scene;
	Stage stage;
	Label label;
	ToggleButton toggleButton;
	long previousTime;
	long delay;
	AnimationTimerClass animationTimerClass;
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		this.stage = stage;
		stage.setTitle("Grid Viewer");
		stage.setResizable(false);
		stage.sizeToScene();
		
		Group root = new Group();
		scene = new Scene(root, 500, 500);
		stage.setScene(scene);
		
		Boolean[][] booleanArrayArray = {{true, false, true, true}, {true, false, false, true}, {true, false, true, false}, {false, false, false, true}, {false, false, true, true}, {true, true, true, true}};
		model = new P5_Fu_Andrew_LifeModel(booleanArrayArray);
		borderPane = new BorderPane();
		HBox hBox = new HBox(5);
		hBox.setAlignment(Pos.CENTER_LEFT);
		hBox.setPadding(new Insets(0, 0, 0, 10));
		hBox.setPrefWidth(500);
		hBox.setPrefHeight(50);
		hBox.setStyle("-fx-background-color: #A9A9A9;");
		Button button = new Button("Clear");
		button.setOnAction(new ClearHandler());
		hBox.getChildren().add(button);
		button = new Button("Next Generation");
		button.setOnAction(new NextGenerationHandler());
		hBox.getChildren().add(button);
		label = new Label("Generation\n0");
		label.setTextAlignment(TextAlignment.CENTER);
		hBox.getChildren().add(label);
		model.addGenerationListener(this);
		Slider slider = new Slider();
		slider.setValue(10);
		slider.valueProperty().addListener(new SliderListener());
		slider.setMajorTickUnit(20);
		slider.setMinorTickCount(10);
		slider.setShowTickLabels(true);
		slider.setShowTickMarks(true);
		hBox.getChildren().add(slider);
		toggleButton = new ToggleButton("Animation");
		toggleButton.setOnAction(new ToggleButtonHandler());
		hBox.getChildren().add(toggleButton);
		slider = new Slider();
		slider.setMax(100000000);
		slider.setValue(100000000);
		slider.valueProperty().addListener(new DelaySliderListener());
		hBox.getChildren().add(slider);
		borderPane.setBottom(hBox);
		view = new BooleanGridPane();
		view.setOnMousePressed(new GridMouseHandler());
		view.setOnMouseDragged(new GridMouseHandler());
		MenuBar menubar = new MenuBar();
		Menu menu = new Menu("File");
		MenuItem menuItem = new MenuItem("Open");
		menuItem.setOnAction(new LoadHandler());
		menu.getItems().add(menuItem);
		menuItem = new MenuItem("Save");
		menuItem.setOnAction(new SaveHandler());
		menu.getItems().add(menuItem);
		menubar.getMenus().add(menu);
		borderPane.setTop(menubar);
		view.setModel(model);
		borderPane.setCenter(view);
		borderPane.getCenter().setTranslateY(scene.getHeight() / 2 - view.getTileSize() * model.getNumRows() / 2);
		borderPane.getBottom().setTranslateY(scene.getHeight() - 80 - view.getTileSize() * model.getNumRows());
		root.getChildren().add(borderPane);
		delay = 1000000000;
		previousTime = 0;
		animationTimerClass = new AnimationTimerClass();
		stage.show();
	}

	class GridMouseHandler implements EventHandler<MouseEvent> {

		@Override
		public void handle(MouseEvent event) {
			if(event.getButton() == MouseButton.PRIMARY) {
				model.setValueAt(view.rowForYPos(event.getY()), view.colForXPos(event.getX()), true);
			} else if(event.getButton() == MouseButton.SECONDARY) {
				model.setValueAt(view.rowForYPos(event.getY()), view.colForXPos(event.getX()), false);
			}
			
		}
	}
	
	class LoadHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Open Resource File");
			fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.txt"));
			File selectedFile = fileChooser.showOpenDialog(stage);
			try {
				Scanner scanner = new Scanner(selectedFile);
				Boolean[][] booleanArrayArray = new Boolean[Integer.parseInt(scanner.next())][Integer.parseInt(scanner.next())];
				for(int i = 0; i < booleanArrayArray.length * booleanArrayArray[0].length; i++) {
					booleanArrayArray[i / booleanArrayArray[0].length][i % booleanArrayArray[0].length] = scanner.next().equals("X");
				}
				model = new P5_Fu_Andrew_LifeModel(booleanArrayArray);
				view.setModel(model);
				borderPane.getCenter().setTranslateY(scene.getHeight() / 2 - view.getTileSize() * model.getNumRows() / 2);
				borderPane.getBottom().setTranslateY(scene.getHeight() - 80 - view.getTileSize() * model.getNumRows());
			} catch (FileNotFoundException e) {
				
			}
		}
		
	}
	
	class ClearHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			for(int i = 0; i < model.getNumRows(); i++) {
				for(int j = 0; j < model.getNumCols(); j++) {
					model.setValueAt(i, j, false);
				}
			}
			model.setGeneration(0);
		}
		
	}
	
	class NextGenerationHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			model.nextGeneration();
			view.setModel(model);
		}
		
	}
	
	class SaveHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			Scanner scanner = new Scanner(System.in);
			try {
				File file = new File(scanner.next() + ".txt");
				file.createNewFile();
				FileWriter fileWriter = new FileWriter(file);
				fileWriter.write(model.getNumRows() + " " + model.getNumCols() + "\n");
				for(int i = 0; i < model.getNumRows(); i++) {
					for(int j = 0; j < model.getNumCols(); j++) {
						if(model.getValueAt(i, j)) {
							fileWriter.write("X ");
						} else {
							fileWriter.write("O ");
						}
					}
					fileWriter.write("\n");
				}
				fileWriter.flush();
			} catch (IOException e) {
				
			}
		}
	}
	
	class ToggleButtonHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			if(toggleButton.isSelected()) {
				animationTimerClass.start();
			} else {
				animationTimerClass.stop();
			}
		}
		
	}
	
	class SliderListener implements ChangeListener<Number> {

		@Override
		public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			view.setTileSize((double)newValue);
			borderPane.getCenter().setTranslateY(scene.getHeight() / 2 - view.getTileSize() * model.getNumRows() / 2);
			borderPane.getBottom().setTranslateY(scene.getHeight() - 80 - view.getTileSize() * model.getNumRows());
		}
		
	}
	
	class DelaySliderListener implements ChangeListener<Number> {

		@Override
		public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			delay = newValue.longValue();
		}
		
	}

	@Override
	public void generationChanged(int oldVal, int newVal) {
		label.setText("Generation\n" + newVal);
	}
	
	class AnimationTimerClass extends AnimationTimer {

		@Override
		public void handle(long now) {
			if(now - previousTime >= delay) {
				model.nextGeneration();
				view.setModel(model);
				previousTime = now;
			}
		}

	}
}
