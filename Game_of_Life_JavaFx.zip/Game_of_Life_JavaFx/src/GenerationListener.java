
public interface GenerationListener {
	public void generationChanged(int oldVal, int newVal);
}
