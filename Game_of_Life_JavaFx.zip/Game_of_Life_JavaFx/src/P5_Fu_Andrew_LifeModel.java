import java.util.ArrayList;

public class P5_Fu_Andrew_LifeModel extends GridModel<Boolean> {
	
	ArrayList<GenerationListener> generationListenerArrayList;
	int generation;
	
	public P5_Fu_Andrew_LifeModel(Boolean[][] grid) {
		super(grid);
		generationListenerArrayList = new ArrayList<GenerationListener>();
		generation = 0;
	}
	
	// Method that runs the Life simulation through the given generation
	// Generation 0 is the initial position, Generation 1 is the position after one round of Life, etc
	public void runLife(int numGenerations) {
		int[] integerArray = {0, 1, 1, 1, 0, -1, -1, -1};
    	int[] secondIntegerArray = {1, 1, 0, -1, -1, -1, 0, 1};
		for(int i = 0; i < numGenerations; i++) {
			boolean[][] secondBooleanArrayArray = new boolean[getNumRows()][getNumCols()];
			for(int j = 0; j < getNumRows() * getNumCols(); j++) {
				int integer = 0;
				for(int k = 0; k < 8; k++) {
		    		if(integerArray[k] + j / getNumCols() >= 0 && integerArray[k] + j / getNumCols() < getNumRows() && secondIntegerArray[k] + j % getNumCols() >= 0 && secondIntegerArray[k] + j % getNumCols() < getNumCols() && getValueAt(j / getNumCols() + integerArray[k], j % getNumCols() + secondIntegerArray[k])) {
		    			integer++;
		    		}
		    	}
				if(getValueAt(j / getNumCols(), j % getNumCols()) && (integer == 2 || integer == 3) || !getValueAt(j / getNumCols(), j % getNumCols()) && integer == 3) {
					secondBooleanArrayArray[j / getNumCols()][j % getNumCols()] = true;
				}
			}
			for(int j = 0; j < getNumRows() * getNumCols(); j++) {
				setValueAt(j / getNumCols(), j % getNumCols(), secondBooleanArrayArray[j / getNumCols()][j % getNumCols()]);
			}
		}
	}
	// Method that returns the number of living cells in the given row
	// or returns -1 if row is out of bounds.  The first row is row 0.
	public int rowCount(int row) {
		int integer = 0;
		for(int i = 0; i < getNumCols(); i++) {
			if(getValueAt(row, i)) {
				integer++;
			}
		}
		if(integer == 0) {
			return -1;
		}
		return integer;
	}
	// Method that returns the number of living cells in the given column
	// or returns -1 if column is out of bounds.  The first column is column 0.
	public int colCount(int col) {
		int integer = 0;
		for(int i = 0; i < getNumRows(); i++) {
			if(getValueAt(i, col)) {
				integer++;
			}
		}
		if(integer == 0) {
			return -1;
		}
		return integer;
	}
	// Method that returns the total number of living cells on the board
	public int totalCount() {
		int integer = 0;
		for(int i = 0; i < getNumRows() * getNumCols(); i++) {
			if(getValueAt(i / getNumCols(), i % getNumCols())) {
				integer++;
			}
		}
		if(integer == 0) {
			return -1;
		}
		return integer;
	}
	// Prints out the Life array with row and column headers as shown in the example below.
	public void printBoard() {
		for(int i = 0; i < Math.log10(getNumRows()); i++) {
			System.out.print(" ");
		}
		for(int i = 0; i < getNumCols(); i++) {
			System.out.print(i % 10);
		}
		System.out.println();
		for(int i = 0; i < getNumRows(); i++) {
			for(int j = (int)Math.log10(getNumRows() - i - 1); j > 0; j--) {
				System.out.print(" ");
			}
			System.out.print(i);
			for(int j = 0; j < getNumCols(); j++) {
				if(getValueAt(i, j)) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("Number of living cells in row 9 --> " + rowCount(9));
		System.out.println("Number of living cells in col 9 --> " + colCount(9));
		System.out.println("Number of living cells in total --> " + totalCount());
	}
	// Advances Life forward one generation
	public void nextGeneration() {
		runLife(1);
		setGeneration(getGeneration() + 1);
	}
	
	void addGenerationListener(GenerationListener l) {
		generationListenerArrayList.add(l);
	}
	void removeGenerationListener(GenerationListener l) {
		generationListenerArrayList.add(l);
	}
	void setGeneration(int gen) {
		for(int i = 0; i < generationListenerArrayList.size(); i++) {
			generationListenerArrayList.get(i).generationChanged(generation, gen);
		}
		generation = gen;
		
	}
	int getGeneration() {
		return generation;
	}

}