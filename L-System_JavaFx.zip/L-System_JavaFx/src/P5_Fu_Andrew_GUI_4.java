/**
 * Name: Andrew Fu
 * Period: 5
 * Date: March 18th
 * Time: 2:09:43
 * 
 * Learning how to code for GUIs isn't difficult, and I had only spent twenty minutes integrating my 
 * GUI to my procedural generation program. The program I had designed took me more than an hour, 
 * because I had to figure out how to 'remember' coordinates while the recursion took place, and while 
 * the problem wasn't complex, having only required knowledge of right triangle trigonometry, I had 
 * been stumped trying to figure why the coordinates I had wanted to have remembered were inaccurate, 
 * before I can to the realization that Math.sin and Math.cos used radians, while rotation used 
 * degrees, which meant that I had to convert the angles between the two interpretations. After I had 
 * solved the problem, I had fun experimenting with making fractal trees, and making leaf colors. Due 
 * to time constraints, I was unable to add GUI manipulation to my picture, which was supposed to 
 * alter the opacity of the object.
 */

import java.util.ArrayList;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.QuadCurve;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;

public class P5_Fu_Andrew_GUI_4 extends Application {
	
	Stage stage;
	Group root;
	Scene scene;
	int integer;
	int secondInteger;
	String string;
	ArrayList<Double> firstDoubleArrayList = new ArrayList<Double>();
	ArrayList<Double> secondDoubleArrayList = new ArrayList<Double>();
	
	private final double MARBLE_RADIUS = 50;
	private final double MARBLE_X_POSITION = 700;
	private final double MARBLE_Y_POSITION = 300;
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		this.stage = stage;
		stage.setTitle("Happy Little Trees");
		stage.setResizable(false);
		stage.sizeToScene();
		
		Group root = new Group();
		this.root = root;
		Scene scene = new Scene(root, 800, 600);
		this.scene = scene;
		stage.setScene(scene);
		
		integer = 15;
		secondInteger = 50;
		string = "Summer";
		BorderPane borderPane = new BorderPane();
		HBox hBox = new HBox();
		TextField textField = new TextField();
		textField.textProperty().addListener(new TextFieldListener());
		textField.setText("15");
		hBox.getChildren().addAll(new Label("Complexity: "), textField);
		hBox.setPrefWidth(800);
		hBox.setPrefHeight(60);
		hBox.setAlignment(Pos.CENTER);
		borderPane.setTop(hBox);
		VBox vBox = new VBox();
		Slider slider = new Slider();
		slider.setMin(0);
		slider.setMax(100);
		slider.setShowTickLabels(true);
		slider.setShowTickMarks(true);
		slider.setMajorTickUnit(20);
		slider.setValue(50);
		slider.valueProperty().addListener(new SliderListener());
		vBox.getChildren().addAll(new Label("Darkness"), slider);
		vBox.setPrefWidth(200);
		vBox.setPrefHeight(400);
		vBox.setAlignment(Pos.BOTTOM_CENTER);
		borderPane.setRight(vBox);
		vBox = new VBox();
		hBox = new HBox();
		ChoiceBox choiceBox = new ChoiceBox(FXCollections.observableArrayList("Autumn", "Winter", "Spring", "Summer"));
		choiceBox.valueProperty().addListener(new ChoiceBoxListener());
		choiceBox.setValue("Summer");
		hBox.getChildren().addAll(new Label("Season: "), choiceBox);
		hBox.setAlignment(Pos.CENTER);
		slider = new Slider();
		slider.setValue(slider.getMax() / 2);
		vBox.setPrefWidth(200);
		vBox.getChildren().addAll(hBox, slider);
		vBox.setAlignment(Pos.CENTER);
		vBox.setSpacing(10);
		borderPane.setLeft(vBox);
		hBox = new HBox();
		Button button = new Button("Generate");
		button.setOnAction(new ButtonHandler());
		hBox.getChildren().add(button);
		hBox.setPrefHeight(140);
		hBox.setAlignment(Pos.CENTER);
		borderPane.setBottom(hBox);
		root.getChildren().add(borderPane);
		
		QuadCurve quadCurve = new QuadCurve(MARBLE_X_POSITION, MARBLE_Y_POSITION - MARBLE_RADIUS, MARBLE_X_POSITION - (MARBLE_RADIUS - 5), MARBLE_Y_POSITION, MARBLE_X_POSITION, MARBLE_Y_POSITION + MARBLE_RADIUS);
		quadCurve.setFill(Color.RED);
		root.getChildren().add(quadCurve);
		quadCurve = new QuadCurve(MARBLE_X_POSITION, MARBLE_Y_POSITION - MARBLE_RADIUS, MARBLE_X_POSITION - (MARBLE_RADIUS - 5) / 2, MARBLE_Y_POSITION, MARBLE_X_POSITION, MARBLE_Y_POSITION + MARBLE_RADIUS);
		quadCurve.setFill(Color.WHITE);
		root.getChildren().add(quadCurve);
		
		CubicCurve cubicCurve = new CubicCurve(MARBLE_X_POSITION, MARBLE_Y_POSITION - MARBLE_RADIUS, MARBLE_X_POSITION + (MARBLE_RADIUS - 5), MARBLE_Y_POSITION, MARBLE_X_POSITION - (MARBLE_RADIUS - 5), MARBLE_Y_POSITION,MARBLE_X_POSITION, MARBLE_Y_POSITION + MARBLE_RADIUS);
		cubicCurve.setFill(Color.BLUE);
		root.getChildren().add(cubicCurve);
		cubicCurve = new CubicCurve(MARBLE_X_POSITION, MARBLE_Y_POSITION - MARBLE_RADIUS, MARBLE_X_POSITION + (MARBLE_RADIUS - 5) / 2, MARBLE_Y_POSITION, MARBLE_X_POSITION - (MARBLE_RADIUS - 5) / 2, MARBLE_Y_POSITION,MARBLE_X_POSITION, MARBLE_Y_POSITION + MARBLE_RADIUS);
		cubicCurve.setFill(Color.WHITE);
		root.getChildren().add(cubicCurve);
		
		Circle circle = new Circle(MARBLE_X_POSITION, MARBLE_Y_POSITION, MARBLE_RADIUS, Color.rgb(0, 250, 150, 0.1));
		circle.setStrokeWidth(5);
		circle.setStroke(Color.rgb(0, 250, 150, 0.1));
		root.getChildren().add(circle);
		for(int i = 128; i < 255; i++) {
			circle = new Circle(MARBLE_X_POSITION + (MARBLE_RADIUS - MARBLE_RADIUS / 25) * Math.sqrt(2) / 2 * (i - 128) / 255, MARBLE_Y_POSITION + (MARBLE_RADIUS - MARBLE_RADIUS / 25) * Math.sqrt(2) / 2 * (i - 128) / 255, (383.0 - i) * (MARBLE_RADIUS - MARBLE_RADIUS / 25) / 255, Color.rgb(0, 250 * i / 255, 150 * i / 255, 0.01));
			root.getChildren().add(circle);
		}
		
		
		
		stage.show();
	}
	
	private class ButtonHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			function(stage, root, scene, integer, scene.getWidth() / 2, scene.getHeight() - scene.getHeight() / 3, 270);
			
			for(int i = 0; i < firstDoubleArrayList.size(); i++) {
				Circle circle;
				if(string.equals("Summer")) {
					circle = new Circle(firstDoubleArrayList.get(i), secondDoubleArrayList.get(i), 1, Color.rgb(0, 255 - (int)(Math.random() * secondInteger), 0));
				} else if(string.equals("Autumn")) {
					circle = new Circle(firstDoubleArrayList.get(i), secondDoubleArrayList.get(i), 1, Color.rgb(255 - (int)(Math.random() * secondInteger), (int)(Math.random() * (255 - (int)(Math.random() * secondInteger))), 0));
				} else if(string.equals("Winter")) {
					circle = new Circle(firstDoubleArrayList.get(i), scene.getHeight() - scene.getHeight() / 3 - scene.getHeight() / secondDoubleArrayList.get(i), 1, Color.rgb((int)(Math.random() * 205) + 100 - secondInteger, (int)(Math.random() * 105) + 100 - secondInteger, 0));
				} else {
					circle = new Circle(firstDoubleArrayList.get(i), secondDoubleArrayList.get(i), 1, Color.rgb((int)(Math.random() * (255 - (int)(Math.random() * secondInteger))), 255 - (int)(Math.random() * secondInteger), 0));
				}
				root.getChildren().add(circle);
			}
		}
		
	}
	
	private class ChoiceBoxListener implements ChangeListener<String> {

		@Override
		public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
			string = newValue;
		}
		
	}
	
	private class SliderListener implements ChangeListener<Number> {

		@Override
		public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			secondInteger = (int)(double)newValue;
		}
		
	}
	
	private class TextFieldListener implements ChangeListener<CharSequence> {

		@Override
		public void changed(ObservableValue<? extends CharSequence> observable, CharSequence oldValue,
				CharSequence newValue) {
			try { 
	            integer = Integer.parseInt(newValue.toString());
	        } catch (NumberFormatException e) {
	        	
	        } 
		}
		
	}
	
	public void function(Stage stage, Group root, Scene scene, int integer, double firstDoubleVariable, double secondDoubleVariable, double thirdDoubleVariable) {
		if(integer <= 1) {
			firstDoubleArrayList.add(firstDoubleVariable);
			secondDoubleArrayList.add(secondDoubleVariable);
		} else if(secondDoubleVariable <= scene.getHeight() - scene.getHeight() / 3 - this.integer * 2 || integer == this.integer) {
			Rectangle rectangle = new Rectangle(firstDoubleVariable, secondDoubleVariable, integer * 2, integer / 4);
			rectangle.setFill(Color.SADDLEBROWN);
			rectangle.getTransforms().add(new Rotate(thirdDoubleVariable, firstDoubleVariable, secondDoubleVariable));
			root.getChildren().add(rectangle);
			function(stage, root, scene, integer - (int)(Math.random() * 2) - 1, firstDoubleVariable + integer * 2 * Math.cos(Math.toRadians(thirdDoubleVariable)), secondDoubleVariable + integer * 2 * Math.sin(Math.toRadians(thirdDoubleVariable)), thirdDoubleVariable + (int)(Math.random() * (45 - 90.0 / integer)));
			function(stage, root, scene, integer - (int)(Math.random() * 4) - 3, firstDoubleVariable + integer * 2 * Math.cos(Math.toRadians(thirdDoubleVariable)), secondDoubleVariable + integer * 2 * Math.sin(Math.toRadians(thirdDoubleVariable)), thirdDoubleVariable + (int)(Math.random() * (45 - 90.0 / integer)));
			function(stage, root, scene, integer - (int)(Math.random() * 2) - 1, firstDoubleVariable + integer * 2 * Math.cos(Math.toRadians(thirdDoubleVariable)), secondDoubleVariable + integer * 2 * Math.sin(Math.toRadians(thirdDoubleVariable)), thirdDoubleVariable - (int)(Math.random() * (45 - 90.0 / integer)));
			function(stage, root, scene, integer - (int)(Math.random() * 4) - 3, firstDoubleVariable + integer * 2 * Math.cos(Math.toRadians(thirdDoubleVariable)), secondDoubleVariable + integer * 2 * Math.sin(Math.toRadians(thirdDoubleVariable)), thirdDoubleVariable - (int)(Math.random() * (45 - 90.0 / integer)));
		}
	}
}
