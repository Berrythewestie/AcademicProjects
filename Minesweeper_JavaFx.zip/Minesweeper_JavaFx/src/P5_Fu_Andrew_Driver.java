/**
 * Name: Andrew Fu
 * Period: 5
 * Date: April 6th
 * Time: 5:03:51
 * 
 * I am not entirely satisfied with how the code for this project turned out, and I would not even 
 * know how to begin reconstructing it. One of the biggest errors I made was swapping the rows with 
 * the columns, and I had only realized this after I built my controller around it. Another 
 * thing that bothered me slightly was having to create an unusual amount of 'global' variables 
 * inside of the scope of the controller class. I spent most of my time checking for bugs, and fixing 
 * them. The broken auto-play feature was assembled within thirty minutes.
 */

import javafx.stage.Screen;
import javafx.stage.Stage;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

public class P5_Fu_Andrew_Driver extends Application {

	public static final int BEGINNER_NUMBER_OF_ROWS = 8;
	public static final int BEGINNER_NUMBER_OF_COLUMNS = 8;
	public static final int BEGINNER_NUMBER_OF_MINES = 10;
	public static final int NUMBER_OF_ROWS = 23;
	public static final int NUMBER_OF_COLUMNS = 44;
	public static final int NUMBER_OF_MINES = 202;
	private Label minesRemaining;
	private Label timeElapsed;
	private VBox vBox;
	private int headerHeight;
	private P5_Fu_Andrew_MinesweeperModel board;
	private boolean firstMove;
	private boolean isCheating;
	private boolean isUpdating;
	private int centerX;
	private int centerY;
	private int boardFirstRow;
	private int boardFirstCol;
	Image blank;
	Image bombDeath;
	Image bombFlagged;
	Image bombQuestion;
	Image bombRevealed;
	Image bombWrong;
	Image faceDead;
	Image faceOoh;
	Image faceSmile;
	Image faceWin;
	String[] imageArray;
	Robot robot;

	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		firstMove = true;
		isCheating = false;
		isUpdating = false;
		blank = new Image("blank.gif");
		bombDeath = new Image("bomb_death.gif");
		bombFlagged = new Image("bomb_flagged.gif");
		bombQuestion = new Image("bomb_question.gif");
		bombRevealed = new Image("bomb_revealed.gif");
		bombWrong = new Image("bomb_wrong.gif");
		faceDead = new Image("face_dead.gif");
		faceOoh = new Image("face_ooh.gif");
		faceSmile = new Image("face_smile.gif");
		faceWin = new Image("face_win.gif");
		imageArray = new String[9];
		for(int i = 0; i < 9; i++) {
			imageArray[i] = new String("num_" + i + ".gif");
		}
		
		stage.setTitle("Grid Viewer");
		stage.setResizable(false);
		stage.sizeToScene();
		
		Group root = new Group();
		
		board = new P5_Fu_Andrew_MinesweeperModel();
		board.initialize(NUMBER_OF_COLUMNS, NUMBER_OF_ROWS);
		board.setNumMines(NUMBER_OF_MINES);
		BorderPane borderPane = new BorderPane();
		borderPane.setPadding(new Insets(16, 16, 16, 16));
		MenuBar menuBar = new MenuBar();
		Menu menu = new Menu("Game");
		MenuItem menuItem = new MenuItem("New Beginner Game");
		menuItem.setOnAction(new newBeginnerGameHandler());
		menu.getItems().add(menuItem);
		menuItem = new MenuItem("Exit");
		menuItem.setOnAction(new exitHandler());
		menu.getItems().add(menuItem);
		menuBar.getMenus().add(menu);
		menu = new Menu("Options");
		menuItem = new MenuItem("Set Number of Mines");
		menuItem.setOnAction(new setNumberOfMinesHandler());
		menu.getItems().add(menuItem);
		menuItem = new MenuItem("This only works for the original scene size and is broken and incomplete. Sorry.");
		menuItem.setOnAction(new anInsignificantMenuItemHandler());
		menu.getItems().add(menuItem);
		menuBar.getMenus().add(menu);
		menu = new Menu("Help");
		menuItem = new MenuItem("About");
		menuItem.setOnAction(new aboutHandler());
		menu.getItems().add(menuItem);
		menuBar.getMenus().add(menu);
		borderPane.setTop(menuBar);
		vBox = new VBox(4);
		vBox.setPadding(new Insets(8, 8, 8, 8));
		vBox.setAlignment(Pos.CENTER);
		vBox.getChildren().add(new Label("Mines Remaining"));
		minesRemaining = new Label(Integer.toString(NUMBER_OF_MINES));
		vBox.getChildren().add(minesRemaining);
		borderPane.setLeft(vBox);
		vBox = new VBox(4);
		vBox.setPadding(new Insets(8, 8, 8, 8));
		vBox.setAlignment(Pos.CENTER);
		vBox.getChildren().add(new Label("Time Elapsed"));
		timeElapsed = new Label("0");
		vBox.getChildren().add(timeElapsed);
		borderPane.setRight(vBox);
		vBox = new VBox();
		for(int i = 0; i < board.getNumCols(); i++) {
			HBox hBox = new HBox();
			for(int j = 0; j < board.getNumRows(); j++) {
				ImageView imageView = new ImageView(blank);
				imageView.setOnMouseClicked(new imageViewHandler());
				hBox.getChildren().add(imageView);
			}
			vBox.getChildren().add(hBox);
		}
		borderPane.setBottom(vBox);
		root.getChildren().add(borderPane);
		headerHeight = (int)(menuBar.getHeight() + vBox.getHeight() + 64);
		Scene scene = new Scene(root, 32 * (board.getNumRows() + 1), 32 * (board.getNumCols() + 1) + headerHeight + 16);
		stage.setScene(scene);
		robot = new Robot();
		centerX = (int)Screen.getPrimary().getBounds().getWidth() / 2;
		centerY = (int)Screen.getPrimary().getBounds().getHeight() / 2 + headerHeight;
		boardFirstRow = centerX - board.getNumRows() * 16 + 16;
		boardFirstCol = centerY - board.getNumCols() * 16 + 16;
		robot.setAutoDelay(1);
		robot.setAutoWaitForIdle(true);
		
		stage.show();
	}
	
	private class imageViewHandler implements EventHandler<MouseEvent> {

		@Override
		public void handle(MouseEvent event) {
			boolean gameOver = false;
			if(event.getButton() == MouseButton.PRIMARY && !board.isFlagged((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1))) {
				if(firstMove) {
					board.initializeBoard(NUMBER_OF_MINES, (int)(event.getSceneX() - 16) / 32, (int)(event.getSceneY() - headerHeight) / 32 - 1);
					animationTimer.start();
					firstMove = false;
				}
				if(board.isCellBlank((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1))) {
					board.recursiveReveal((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1));
				} else {
					board.reveal((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1));
				}
				gameOver = board.isMine((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1));
			} else if(event.getButton() == MouseButton.SECONDARY) {
				if(board.isFlagged((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1))) {
					if(!isCheating) {
						board.removeFlag((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1));
					}
				} else {
					board.setFlag((int)(event.getSceneX() - 16) / 32, ((int)(event.getSceneY() - headerHeight) / 32 - 1));
				}
				minesRemaining.setText(Integer.toString(board.getNumFlags()));
			}
			for(int i = 0; i < board.getNumRows(); i++) {
				for(int j = 0; j < board.getNumCols(); j++) {
					ImageView imageView = new ImageView(blank);
					if(board.isFlagged(i, j)) {
						if(gameOver && !board.isMine(i, j)) {
							imageView = new ImageView(bombWrong);
						} else {
							imageView = new ImageView(bombFlagged);
						}
					} else if(board.isRevealed(i, j)) {
						if(board.isMine(i, j)) {
							imageView = new ImageView(bombDeath);
						} else {
							imageView = new ImageView(imageArray[board.getValue(i, j) % 20]);
						}
					} else if(gameOver && board.isMine(i, j)) {
						imageView = new ImageView(bombRevealed);
					}
					if(!gameOver && !board.noEmptyCellsRemaining() && !board.isRevealed(i, j)) {
						imageView.setOnMouseClicked(new imageViewHandler());
					}
					((HBox)vBox.getChildren().get(j)).getChildren().set(i, imageView);
				}
			}
			if(board.noEmptyCellsRemaining()) {
				animationTimer.stop();
				Alert alert = new Alert(AlertType.INFORMATION, "You win!!!", ButtonType.OK);
				alert.showAndWait();
			} else if(gameOver) {
				animationTimer.stop();
				Alert alert = new Alert(AlertType.INFORMATION, "Sorry, you lose :(", ButtonType.OK);
				alert.showAndWait();
			}
			if(isUpdating) {
				robot.keyPress(KeyEvent.VK_ALT);
				robot.keyRelease(KeyEvent.VK_ALT);
				robot.keyPress(KeyEvent.VK_RIGHT);
				robot.keyRelease(KeyEvent.VK_RIGHT);
				for(int i = 0; i < 3; i++) {
					robot.keyPress(KeyEvent.VK_DOWN);
					robot.keyRelease(KeyEvent.VK_DOWN);
				}
				robot.keyPress(KeyEvent.VK_SPACE);
				robot.keyRelease(KeyEvent.VK_SPACE);
				isUpdating = false;
			}
		}
	}
	
	private class newBeginnerGameHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			animationTimer.stop();
			board = new P5_Fu_Andrew_MinesweeperModel();
			board.initialize(BEGINNER_NUMBER_OF_COLUMNS, BEGINNER_NUMBER_OF_ROWS);
			board.setNumMines(BEGINNER_NUMBER_OF_MINES);
			minesRemaining.setText(Integer.toString(BEGINNER_NUMBER_OF_MINES));
			timeElapsed.setText("0");
			firstMove = true;
			vBox.getChildren().clear();
			for(int i = 0; i < board.getNumCols(); i++) {
				HBox hBox = new HBox();
				for(int j = 0; j < board.getNumRows(); j++) {
					ImageView imageView = new ImageView(blank);
					imageView.setOnMouseClicked(new imageViewHandler());
					hBox.getChildren().add(imageView);
				}
				vBox.getChildren().add(hBox);
			}
		}
		
	}
	
	private class exitHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			System.exit(0);
		}
		
	}
	
	private class setNumberOfMinesHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			if(firstMove) {
				String answer = Integer.toString(Integer.MAX_VALUE);
				while(Integer.parseInt(answer) > board.getNumRows() * board.getNumCols() - 9) {
					TextInputDialog input = new TextInputDialog();
					input.setHeaderText("How many mines would you like?");
					input.showAndWait();
					answer = input.getEditor().getText();
				}
				board.setNumMines(Integer.parseInt(answer));
				minesRemaining.setText(board.numBombsRemaining() + "");
			} else {
				Alert alert = new Alert(AlertType.ERROR, "You can only set the number of mines on the board before your first move.", ButtonType.OK);
				alert.showAndWait();
			}
		}
		
	}
	
	private class anInsignificantMenuItemHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			isUpdating = true;
			isCheating = true;
			if(firstMove) {
				robot.mouseMove(centerX + 16, centerY);
				robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
				robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			} else {
				for(int i = 0; i < board.getNumRows(); i++) {
					for(int j = 0; j < board.getNumCols(); j++) {
						if(board.isRevealed(i, j) && board.getValue(i, j) < board.getValue(i, j) % 20 + 40) {
							int[] integerArray = {0, 1, 1, 1, 0, -1, -1, -1};
							ArrayList<Integer> firstIntegerArrayList = new ArrayList<Integer>();
							ArrayList<Integer> secondIntegerArrayList = new ArrayList<Integer>();
							int integer = 0;
							for(int k = 0; k < 8; k++) {
								if(board.isInBounds(i + integerArray[k], j + integerArray[(k + 2) % 8]) && !board.isRevealed(i + integerArray[k], j + integerArray[(k + 2) % 8])) {
									if(board.isFlagged(i + integerArray[k], j + integerArray[(k + 2) % 8])) {
										integer++;
									} else {
										firstIntegerArrayList.add(i + integerArray[k]);
										secondIntegerArrayList.add(j + integerArray[(k + 2) % 8]);
									}
								}
							}
							if(!board.isCellBlank(i, j) && board.getValue(i, j) % 20 - integer == firstIntegerArrayList.size()) {
								for(int k = 0; k < firstIntegerArrayList.size(); k++) {
									robot.mouseMove(boardFirstRow + 32 * firstIntegerArrayList.get(k), boardFirstCol + 32 * secondIntegerArrayList.get(k));
									robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
									robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
									board.reveal(i, j);
								}
							} else if(!board.isCellBlank(i, j) && board.getValue(i, j) % 20 == integer) {
								for(int k = 0; k < firstIntegerArrayList.size(); k++) {
									robot.mouseMove(boardFirstRow + 32 * firstIntegerArrayList.get(k), boardFirstCol + 32 * secondIntegerArrayList.get(k));
									robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
									robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
									board.reveal(i, j);
								}
							}
						}
					}
				}
			}
		}
		
	}
	
	private class aboutHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			Stage stage = new Stage();
			stage.setTitle("About");
			stage.setResizable(false);
			stage.sizeToScene();
			
			Group root = new Group();
			Scene scene = new Scene(root, 200, 200);
			stage.setScene(scene);
			
			root.getChildren().add(new Label("Minesweeper\n1.0\nAndrew Fu"));
			
			stage.show();
		}
		
	}
	
	private AnimationTimer animationTimer = new AnimationTimer() {

		long start;
		long second;

		public void start() {
			super.start();
			start = System.currentTimeMillis();
			second = 1000;
		}
		
		@Override
		public void handle(long now) {
			now = System.currentTimeMillis();
			if(now - start >= second) {
				second += 1000;
				timeElapsed.setText(Long.toString((now - start) / 1000));
			}
		}
		
	};
}
