
public class P5_Fu_Andrew_MinesweeperModel implements MSModelInterface {

	private int[][] board;
	private int numMines;

	public void removeCell(int row, int col) {
		board[row][col] = 0;
	}

	public boolean isInBounds(int row, int col) {
		return row >= 0 && row < getNumRows() && col >= 0 && col < getNumCols();
	}

	public boolean isMine(int row, int col) {
		return getValue(row, col) % 10 == 9;
	}

	public boolean isCellBlank(int row, int col) {
		return getValue(row, col) % 10 == 0;
	}

	public void setFlag(int row, int col) {
		board[row][col] += 10;
	}

	public void recursiveReveal(int row, int col) {
		int[] integerArray = {0, 1, 1, 1, 0, -1, -1, -1};
		for(int i = 0; i < 8; i++) {
			if(isInBounds(row + integerArray[i], col + integerArray[(i + 2) % 8]) && !isRevealed(row + integerArray[i], col + integerArray[(i + 2) % 8])) {
				reveal(row + integerArray[i], col + integerArray[(i + 2) % 8]);
				if(isCellBlank(row + integerArray[i], col + integerArray[(i + 2) % 8])) {
					recursiveReveal(row + integerArray[i], col + integerArray[(i + 2) % 8]);
				}
			}
		}
		if(!isRevealed(row, col)) {
			reveal(row, col);
		}
	}
	
	public void reveal(int row, int col) {
		board[row][col] += 20;
	}

	public void initializeBoard(int numMines, int row, int col) {
		numMines = this.numMines;
		int[] integerArray = {0, 1, 1, 1, 0, -1, -1, -1};
		for(int i = 0; i < numMines; i++) {
			int integer = (int)(Math.random() * (getNumRows() * getNumCols() - i - 9));
			for(int j = 0; j <= integer; j++) {
				if(isMine(j / getNumCols(), j % getNumCols()) || j / getNumCols() == row && j % getNumCols() == col) {
					integer++;
				}
				for(int k = 0; k < 8; k++) {
					if(isInBounds(row + integerArray[k], col + integerArray[(k + 2) % 8]) && j / getNumCols() == row + integerArray[k] && j % getNumCols() == col + integerArray[(k + 2) % 8]) {
						integer++;
					}
				}
			}
			board[integer / getNumCols()][integer % getNumCols()] += 9;
		}
		for(int i = 0; i < getNumRows() * getNumCols(); i++) {
			if(isCellBlank(i / getNumCols(), i % getNumCols())) {
				board[i / getNumCols()][i % getNumCols()] += getNumMineNeighbors(i / getNumCols(), i % getNumCols());
			}
		}
	}

	public boolean isRevealed(int row, int col) {
		return getValue(row, col) > 19;
	}

	public void setNumMines(int numMines) {
		this.numMines = numMines;
	}

	public int getNumRows() {
		return board.length;
	}

	public int getNumCols() {
		return board[0].length;
	}

	public boolean isFlagged(int row, int col) {
		return getValue(row, col) > 9 && getValue(row, col) <= 19;
	}

	public int getNumFlags() {
		return numMines - numFlagsPlaces();
	}

	public void initialize(int row, int col) {
		board = new int[row][col];
	}

	public int numBombsRemaining() {
		int integer = 0;
		for(int i = 0; i < getNumRows() * getNumCols(); i++) {
			if(isMine(i / getNumCols(), i % getNumCols()) && isFlagged(i / getNumCols(), i % getNumCols())) {
				integer++;
			}
		}
		return numMines - integer;
	}

	public int numFlagsPlaces() {
		int integer = 0;
		for(int i = 0; i < getNumRows() * getNumCols(); i++) {
			if(isFlagged(i / getNumCols(), i % getNumCols())) {
				integer++;
			}
		}
		return integer;
	}

	public boolean noEmptyCellsRemaining() {
		for(int i = 0; i < getNumRows() * getNumCols(); i++) {
			if(!isRevealed(i / getNumCols(), i % getNumCols()) && !isFlagged(i / getNumCols(), i % getNumCols())) {
				return false;
			}
		}
		return true;
	}

	public int getNumMineNeighbors(int row, int col) {
		int integer = 0;
		int[] integerArray = {0, 1, 1, 1, 0, -1, -1, -1};
		for(int i = 0; i < 8; i++) {
			if(isInBounds(row + integerArray[i], col + integerArray[(i + 2) % 8]) && isMine(row + integerArray[i], col + integerArray[(i + 2) % 8])) {
				integer++;
			}
		}
		return integer;
	}

	public void removeFlag(int row, int col) {
		board[row][col] -= 10;
	}

	public int getValue(int row, int col) {
		return board[row][col];
	}
}
