
public interface MSModelInterface {
	public void removeCell(int row, int col);
//	public int getNumMines(int row, int col);
	public boolean isInBounds(int row, int col);
//	public int mouseYToRow(int yPos);
//	public int mouseXToCol(int xPos);
	public boolean isMine(int row, int col);
	public boolean isCellBlank(int row, int col);
	public void setFlag(int row, int col);
	public void recursiveReveal(int row, int col);
	public void reveal(int row, int col);
//	public boolean isGameWon();
	public void initializeBoard(int numMines, int row, int col);
	public boolean isRevealed(int row, int col);
	public void setNumMines(int numMines);
	public int getNumRows();
	public int getNumCols();
	public boolean isFlagged(int row, int col);
//	public void clearFlag(int row, int col);
	public int getNumFlags();
	public void initialize(int row, int col);
//	public boolean isBomb(int row, int col);
	public int numBombsRemaining();
	public int numFlagsPlaces();
	public boolean noEmptyCellsRemaining();
//	public void unFlag(int row, int col);
//	public void Constructor(int numRows, int numCols);
	public int getNumMineNeighbors(int row, int col);
	public void removeFlag(int row, int col);
//	public int numFlags();
//	public void setDifficulty();
//	public void reset();
	public int getValue(int row, int col);
}
