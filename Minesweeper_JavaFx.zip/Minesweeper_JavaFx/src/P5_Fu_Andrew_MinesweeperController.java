import java.util.Scanner;

public class P5_Fu_Andrew_MinesweeperController {

	P5_Fu_Andrew_MinesweeperModel board;
	int numMines;
	int row;
	int col;
	Scanner scanner;

	public P5_Fu_Andrew_MinesweeperController(int numMines, int row, int col) {
		board = new P5_Fu_Andrew_MinesweeperModel();
		this.numMines = numMines;
		scanner = new Scanner(System.in);
		board.initialize(row, col);
		System.out.println("        _                                                   \n" + 
				"  /\\/\\ (_)_ __   ___  _____      _____  ___ _ __   ___ _ __ \n" + 
				" /    \\| | '_ \\ / _ \\/ __\\ \\ /\\ / / _ \\/ _ \\ '_ \\ / _ \\ '__|\n" + 
				"/ /\\/\\ \\ | | | |  __/\\__ \\\\ V  V /  __/  __/ |_) |  __/ |   \n" + 
				"\\/    \\/_|_| |_|\\___||___/ \\_/\\_/ \\___|\\___| .__/ \\___|_|   \n" + 
				"                                           |_|              \n" + 
				"");
		printBoard();
		board.initializeBoard(numMines, this.row, this.col);
		if(board.isCellBlank(this.row, this.col)) {
			board.recursiveReveal(this.row, this.col);
		}
	}
	
	public void play() {
		printBoard();
		if(board.isCellBlank(this.row, this.col)) {
			board.recursiveReveal(this.row, this.col);
		}
		if(board.noEmptyCellsRemaining()) {
			System.out.println("You win!!!\n" + 
					"\n" + 
					"Want to play again? (Enter 'y' or 'n')\n" + 
					"");
			String string = scanner.next();
			if(string.charAt(0) == 'y') {
				board = new P5_Fu_Andrew_MinesweeperModel();
				this.numMines = numMines;
				board.initialize(row, col);
				System.out.println("        _                                                   \n" + 
						"  /\\/\\ (_)_ __   ___  _____      _____  ___ _ __   ___ _ __ \n" + 
						" /    \\| | '_ \\ / _ \\/ __\\ \\ /\\ / / _ \\/ _ \\ '_ \\ / _ \\ '__|\n" + 
						"/ /\\/\\ \\ | | | |  __/\\__ \\\\ V  V /  __/  __/ |_) |  __/ |   \n" + 
						"\\/    \\/_|_| |_|\\___||___/ \\_/\\_/ \\___|\\___| .__/ \\___|_|   \n" + 
						"                                           |_|              \n" + 
						"");
				printBoard();
				board.initializeBoard(numMines, this.row, this.col);
				if(board.isCellBlank(this.row, this.col)) {
					board.recursiveReveal(this.row, this.col);
				}
			} else if (string.charAt(0) == 'n') {
				System.out.println("Goodbye.  Thanks for playing!");
				System.exit(0);
			}
		}
	}
	
	public void printBoard() {
		for(int i = 0; i < board.getNumRows(); i++) {
			for(int j = 0; j < board.getNumCols(); j++) {
				if(board.isRevealed(i, j)) {
					if(board.isCellBlank(i, j)) {
						System.out.print("  ");
					} else if(board.isMine(i, j)) {
						System.out.print("* ");
					} else {
						System.out.print(board.getValue(i, j) % 10 + " ");
					}
				} else if(board.isFlagged(i, j)) {
					System.out.print("F ");
				} else {
					System.out.print("_ ");
				}
			}
			System.out.print("	");
			for(int j = 0; j < board.getNumCols(); j++) {
				if(board.isMine(i, j)) {
					System.out.print("* ");
				} else {
					if(board.isCellBlank(i, j)) {
						System.out.print("  ");
					} else {
						System.out.print(board.getValue(i, j) % 10 + " ");
					}
				}
			}
			System.out.println();
		}
		System.out.print("There are " + board.getNumFlags() + " mines left.\nWould you like to flag a cell or reveal a cell?\nEnter 'f' or 'r' > ");
		Scanner scanner = new Scanner(System.in);
		String string = scanner.next();
		System.out.print("Enter a row: ");
		row = Integer.parseInt(scanner.next());
		System.out.print("Enter a column: ");
		col = Integer.parseInt(scanner.next());
		if(string.charAt(0) == 'f') {
			if(board.isFlagged(row, col)) {
				board.removeFlag(row, col);
			} else if(!board.isRevealed(row, col)) {
				board.setFlag(row, col);
			}
		} else if(string.charAt(0) == 'r') {
			if(board.isMine(row, col) && !board.isFlagged(row, col)) {
				System.out.println("Sorry, you lose :(\n" + 
						"\n" + 
						"Want to play again? (Enter 'y' or 'n')\n" + 
						"");
				string = scanner.next();
				if(string.charAt(0) == 'y') {
					board = new P5_Fu_Andrew_MinesweeperModel();
					this.numMines = numMines;
					board.initialize(row, col);
					System.out.println("        _                                                   \n" + 
							"  /\\/\\ (_)_ __   ___  _____      _____  ___ _ __   ___ _ __ \n" + 
							" /    \\| | '_ \\ / _ \\/ __\\ \\ /\\ / / _ \\/ _ \\ '_ \\ / _ \\ '__|\n" + 
							"/ /\\/\\ \\ | | | |  __/\\__ \\\\ V  V /  __/  __/ |_) |  __/ |   \n" + 
							"\\/    \\/_|_| |_|\\___||___/ \\_/\\_/ \\___|\\___| .__/ \\___|_|   \n" + 
							"                                           |_|              \n" + 
							"");
					printBoard();
					board.initializeBoard(numMines, this.row, this.col);
					if(board.isCellBlank(this.row, this.col)) {
						board.recursiveReveal(this.row, this.col);
					}
				} else if (string.charAt(0) == 'n') {
					System.out.println("Goodbye.  Thanks for playing!");
					System.exit(0);
				}
			} else if(!board.isFlagged(row, col) && !board.isRevealed(row, col)) {
				board.reveal(row, col);
			}
		}
	}
}
